.onLoad <- function(libname, pkgname) {
    options(datatable.fread.dec.experiment=FALSE)
}
