context("Minitab (.mtp) imports/exports")
require("datasets")

#test_that("Import from Minitab", {})
